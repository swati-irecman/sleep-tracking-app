import React from 'react';

const SleepHistoryCalendar: React.FC = () => {
  return (
    <section>
      <h2>Sleep History (Calendar View)</h2>
      <div className="card">
        <p>Calendar coming soon...</p>
      </div>
    </section>
  );
};

export default SleepHistoryCalendar;
